#!/bin/sh
# Copyright (c) 2012 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

# TODO - make this work for OSX, Linux32 and Linux64 like install_host.sh

#./osx/node ofmeet.remote.control.osx.js
#./linux32/node ofmeet.remote.control.linux32.js
#./linux64/node ofmeet.remote.control.linux64.js